$(document).ready(function(){
    $('.header').height($(window).height());
});
$(document).ready(function() {
    $('.emailSentModal').modal('show');
});
   
   